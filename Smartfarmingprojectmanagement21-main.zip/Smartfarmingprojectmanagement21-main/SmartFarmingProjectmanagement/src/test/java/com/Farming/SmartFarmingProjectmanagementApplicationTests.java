package com.Farming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartFarmingProjectmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
