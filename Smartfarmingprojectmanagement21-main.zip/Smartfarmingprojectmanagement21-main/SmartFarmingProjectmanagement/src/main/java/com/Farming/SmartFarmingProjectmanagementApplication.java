package com.Farming;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartFarmingProjectmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartFarmingProjectmanagementApplication.class, args);
	}

}
